package com.bookplatform.catalog.service;

import com.bookplatform.catalog.entity.Store;
import com.bookplatform.catalog.mapper.StoreMapper;
import com.bookplatform.catalog.repository.StoreRepository;
import com.bookplatform.common.dto.StoreDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StoreService {

    private final StoreRepository storeRepository;

    public StoreService(StoreRepository storeRepository) {
        this.storeRepository = storeRepository;
    }

    public List<StoreDto> listStores() {
        return storeRepository.findAllByOrderByNameAsc().stream()
                .map(StoreMapper::toDto)
                .toList();
    }

    public StoreDto getById(Long id) {
        Store store = storeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Store not found: " + id));
        return StoreMapper.toDto(store);
    }

    public Store requireStore(Long id) {
        return storeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Store not found: " + id));
    }
}
