package com.bookplatform.catalog.controller;

import com.bookplatform.catalog.service.InventoryService;
import com.bookplatform.common.dto.InventoryEventDto;
import com.bookplatform.common.openapi.OpenApiConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@Tag(name = "Inventory", description = "Stock movement audit trail")
public class InventoryController {

    private final InventoryService inventoryService;

    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @GetMapping("/events")
    public List<InventoryEventDto> recentEvents() {
        return inventoryService.recentEvents();
    }
}
