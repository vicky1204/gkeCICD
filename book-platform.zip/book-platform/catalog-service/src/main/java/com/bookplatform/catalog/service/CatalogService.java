package com.bookplatform.catalog.service;

import com.bookplatform.catalog.entity.Book;
import com.bookplatform.catalog.mapper.BookMapper;
import com.bookplatform.catalog.repository.BookRepository;
import com.bookplatform.catalog.repository.BookSpecifications;
import com.bookplatform.catalog.service.ReviewService;
import com.bookplatform.common.dto.BookDto;
import com.bookplatform.common.dto.BookPageResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CatalogService {

    public static final int DEFAULT_PAGE_SIZE = 50;
    public static final int DEFAULT_RECOMMENDED_LIMIT = 6;

    private final BookRepository bookRepository;
    private final ReviewService reviewService;
    private final StoreService storeService;
    private final InventoryService inventoryService;

    public CatalogService(BookRepository bookRepository,
                          ReviewService reviewService,
                          StoreService storeService,
                          InventoryService inventoryService) {
        this.bookRepository = bookRepository;
        this.reviewService = reviewService;
        this.storeService = storeService;
        this.inventoryService = inventoryService;
    }

    public BookPageResponse searchBooks(String query, String category, String language, int page, int size) {
        int pageIndex = Math.max(page, 0);
        int pageSize = size <= 0 ? DEFAULT_PAGE_SIZE : Math.min(size, DEFAULT_PAGE_SIZE);
        Page<Book> result = bookRepository.findAll(
                BookSpecifications.withFilters(query, category, language),
                PageRequest.of(pageIndex, pageSize, Sort.by("category").ascending().and(Sort.by("title").ascending()))
        );
        List<Book> books = result.getContent();
        Map<Long, ReviewService.RatingSummary> ratings = ratingSummaries(books);
        return new BookPageResponse(
                books.stream().map(book -> toDtoWithRatings(book, ratings)).toList(),
                result.getNumber(),
                result.getSize(),
                result.getTotalElements(),
                result.getTotalPages(),
                bookRepository.findDistinctCategories(),
                bookRepository.findDistinctLanguages()
        );
    }

    public List<BookDto> getRecommendedBooks(int limit) {
        int size = Math.min(Math.max(limit, 1), 12);
        Page<Book> result = bookRepository.findAll(
                (root, query, cb) -> cb.greaterThan(root.get("stock"), 0),
                PageRequest.of(0, size, Sort.by(Sort.Direction.DESC, "stock").and(Sort.by("title")))
        );
        List<Book> books = result.getContent();
        Map<Long, ReviewService.RatingSummary> ratings = ratingSummaries(books);
        return books.stream().map(book -> toDtoWithRatings(book, ratings)).toList();
    }

    public BookDto getById(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Book not found: " + id));
        ReviewService.RatingSummary summary = reviewService.ratingSummariesForBooks(List.of(id))
                .getOrDefault(id, new ReviewService.RatingSummary(null, 0));
        return BookMapper.toDto(book, summary.averageRating(), summary.reviewCount());
    }

    @Transactional
    public void reserveStock(Long bookId, int quantity, Long orderId) {
        Book book = requireBook(bookId);
        if (book.getStock() < quantity) {
            throw new IllegalStateException("Insufficient stock for book: " + book.getTitle());
        }
        book.setStock(book.getStock() - quantity);
        bookRepository.save(book);
        inventoryService.recordStockReserved(book, quantity, orderId);
    }

    @Transactional
    public void releaseStock(Long bookId, int quantity, Long orderId) {
        Book book = requireBook(bookId);
        book.setStock(book.getStock() + quantity);
        bookRepository.save(book);
        inventoryService.recordStockReturned(book, quantity, orderId);
    }

    @Transactional
    public BookDto createBook(com.bookplatform.common.dto.CreateBookRequest request) {
        Book book = new Book();
        book.setTitle(request.title());
        book.setAuthor(request.author());
        book.setIsbn(request.isbn());
        book.setPrice(request.price());
        book.setCategory(request.category());
        book.setDescription(request.description());
        book.setStock(request.stock());
        book.setLanguage(request.language());
        book.setImageUrl(request.imageUrl());
        book.setStore(storeService.requireStore(request.storeId()));
        Book saved = bookRepository.save(book);
        inventoryService.recordBookAdded(saved);
        return BookMapper.toDto(saved);
    }

    private Book requireBook(Long bookId) {
        return bookRepository.findById(bookId)
                .orElseThrow(() -> new IllegalArgumentException("Book not found: " + bookId));
    }

    private Map<Long, ReviewService.RatingSummary> ratingSummaries(List<Book> books) {
        List<Long> bookIds = books.stream().map(Book::getId).collect(Collectors.toList());
        return reviewService.ratingSummariesForBooks(bookIds);
    }

    private BookDto toDtoWithRatings(Book book, Map<Long, ReviewService.RatingSummary> ratings) {
        ReviewService.RatingSummary summary = ratings.getOrDefault(book.getId(), new ReviewService.RatingSummary(null, 0));
        return BookMapper.toDto(book, summary.averageRating(), summary.reviewCount());
    }
}
