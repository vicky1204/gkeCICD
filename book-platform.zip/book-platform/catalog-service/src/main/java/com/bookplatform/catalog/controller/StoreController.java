package com.bookplatform.catalog.controller;

import com.bookplatform.catalog.service.StoreService;
import com.bookplatform.common.dto.StoreDto;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/stores")
@Tag(name = "Stores", description = "Offline bookstore partners")
public class StoreController {

    private final StoreService storeService;

    public StoreController(StoreService storeService) {
        this.storeService = storeService;
    }

    @GetMapping
    public List<StoreDto> list() {
        return storeService.listStores();
    }

    @GetMapping("/{id}")
    public StoreDto get(@PathVariable("id") Long id) {
        return storeService.getById(id);
    }
}
