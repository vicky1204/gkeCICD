package com.bookplatform.catalog.mapper;

import com.bookplatform.catalog.entity.Store;
import com.bookplatform.common.dto.StoreDto;

public final class StoreMapper {

    private StoreMapper() {}

    public static StoreDto toDto(Store store) {
        if (store == null) {
            return null;
        }
        return new StoreDto(
                store.getId(),
                store.getName(),
                store.getContactPerson(),
                store.getPhone(),
                store.getEmail(),
                store.getAddressLine(),
                store.getCity(),
                store.getState(),
                store.getPincode(),
                store.getGoogleMapsUrl(),
                store.getOpeningHours()
        );
    }
}
