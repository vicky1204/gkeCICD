package com.bookplatform.catalog.repository;

import com.bookplatform.catalog.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByBookIdOrderByCreatedAtDesc(Long bookId);

    Optional<Review> findByBookIdAndUserId(Long bookId, Long userId);

    @Query("""
            SELECT r.bookId, AVG(r.rating), COUNT(r)
            FROM Review r
            WHERE r.bookId IN :bookIds
            GROUP BY r.bookId
            """)
    List<Object[]> averageRatingByBookIds(@Param("bookIds") List<Long> bookIds);
}
