package com.bookplatform.catalog.controller;

import com.bookplatform.catalog.service.CatalogService;
import com.bookplatform.common.dto.BookDto;
import com.bookplatform.common.dto.BookPageResponse;
import com.bookplatform.common.dto.CreateBookRequest;
import com.bookplatform.common.openapi.OpenApiConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/books")
@Tag(name = "Catalog", description = "Book search, details, and stock reservation")
public class CatalogController {

    private final CatalogService catalogService;

    public CatalogController(CatalogService catalogService) {
        this.catalogService = catalogService;
    }

    @GetMapping
    public BookPageResponse list(@RequestParam(value = "q", required = false) String q,
                                 @RequestParam(value = "category", required = false) String category,
                                 @RequestParam(value = "language", required = false) String language,
                                 @RequestParam(value = "page", defaultValue = "0") int page,
                                 @RequestParam(value = "size", defaultValue = "50") int size) {
        return catalogService.searchBooks(q, category, language, page, size);
    }

    @GetMapping("/recommended")
    public List<BookDto> recommended(@RequestParam(value = "limit", defaultValue = "6") int limit) {
        return catalogService.getRecommendedBooks(limit);
    }

    @GetMapping("/{id}")
    public BookDto get(@PathVariable("id") Long id) {
        return catalogService.getById(id);
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PostMapping
    public ResponseEntity<BookDto> create(@Valid @RequestBody CreateBookRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(catalogService.createBook(request));
    }

    @PostMapping("/{id}/reserve")
    public ResponseEntity<Map<String, String>> reserve(@PathVariable("id") Long id,
                                                       @RequestParam("quantity") int quantity,
                                                       @RequestParam(value = "orderId", required = false) Long orderId) {
        catalogService.reserveStock(id, quantity, orderId);
        return ResponseEntity.ok(Map.of("status", "RESERVED"));
    }

    @PostMapping("/{id}/release")
    public ResponseEntity<Map<String, String>> release(@PathVariable("id") Long id,
                                                       @RequestParam("quantity") int quantity,
                                                       @RequestParam(value = "orderId", required = false) Long orderId) {
        catalogService.releaseStock(id, quantity, orderId);
        return ResponseEntity.ok(Map.of("status", "RETURNED"));
    }
}
