package com.bookplatform.catalog.repository;

import com.bookplatform.catalog.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long>, JpaSpecificationExecutor<Book> {

    @Query("SELECT DISTINCT b.category FROM Book b ORDER BY b.category")
    List<String> findDistinctCategories();

    @Query("SELECT DISTINCT b.language FROM Book b WHERE b.language IS NOT NULL ORDER BY b.language")
    List<String> findDistinctLanguages();
}
