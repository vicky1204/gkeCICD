package com.bookplatform.catalog.service;

import com.bookplatform.catalog.entity.Book;
import com.bookplatform.catalog.entity.Review;
import com.bookplatform.catalog.mapper.ReviewMapper;
import com.bookplatform.catalog.repository.BookRepository;
import com.bookplatform.catalog.repository.ReviewRepository;
import com.bookplatform.common.dto.CreateReviewRequest;
import com.bookplatform.common.dto.ReviewDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final BookRepository bookRepository;

    public ReviewService(ReviewRepository reviewRepository, BookRepository bookRepository) {
        this.reviewRepository = reviewRepository;
        this.bookRepository = bookRepository;
    }

    public List<ReviewDto> getReviewsForBook(Long bookId) {
        ensureBookExists(bookId);
        return reviewRepository.findByBookIdOrderByCreatedAtDesc(bookId).stream()
                .map(ReviewMapper::toDto)
                .toList();
    }

    public Optional<ReviewDto> getUserReview(Long bookId, Long userId) {
        return reviewRepository.findByBookIdAndUserId(bookId, userId).map(ReviewMapper::toDto);
    }

    @Transactional
    public ReviewDto upsertReview(Long bookId, Long userId, CreateReviewRequest request) {
        ensureBookExists(bookId);
        Review review = reviewRepository.findByBookIdAndUserId(bookId, userId).orElseGet(Review::new);
        review.setBookId(bookId);
        review.setUserId(userId);
        review.setUserFullName(request.userFullName());
        review.setRating(request.rating());
        review.setComment(request.comment() == null ? "" : request.comment().trim());
        return ReviewMapper.toDto(reviewRepository.save(review));
    }

    public Map<Long, RatingSummary> ratingSummariesForBooks(List<Long> bookIds) {
        if (bookIds == null || bookIds.isEmpty()) {
            return Map.of();
        }
        Map<Long, RatingSummary> summaries = new HashMap<>();
        for (Object[] row : reviewRepository.averageRatingByBookIds(bookIds)) {
            Long bookId = (Long) row[0];
            double average = ((Number) row[1]).doubleValue();
            int count = ((Number) row[2]).intValue();
            summaries.put(bookId, new RatingSummary(roundAverage(average), count));
        }
        return summaries;
    }

    private void ensureBookExists(Long bookId) {
        if (!bookRepository.existsById(bookId)) {
            throw new IllegalArgumentException("Book not found: " + bookId);
        }
    }

    private static double roundAverage(double average) {
        return Math.round(average * 10.0) / 10.0;
    }

    public record RatingSummary(Double averageRating, int reviewCount) {}
}
