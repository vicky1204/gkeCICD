package com.bookplatform.catalog.mapper;

import com.bookplatform.catalog.entity.InventoryEvent;
import com.bookplatform.common.dto.InventoryEventDto;

public final class InventoryEventMapper {

    private InventoryEventMapper() {}

    public static InventoryEventDto toDto(InventoryEvent event) {
        return new InventoryEventDto(
                event.getId(),
                event.getBookId(),
                event.getBookTitle(),
                event.getStoreId(),
                event.getStoreName(),
                event.getEventType(),
                event.getQuantityChange(),
                event.getStockAfter(),
                event.getOrderId(),
                event.getCreatedAt()
        );
    }
}
