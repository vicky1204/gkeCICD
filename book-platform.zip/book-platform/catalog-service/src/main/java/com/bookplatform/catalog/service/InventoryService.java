package com.bookplatform.catalog.service;

import com.bookplatform.catalog.entity.Book;
import com.bookplatform.catalog.entity.InventoryEvent;
import com.bookplatform.catalog.entity.Store;
import com.bookplatform.catalog.mapper.InventoryEventMapper;
import com.bookplatform.catalog.repository.InventoryEventRepository;
import com.bookplatform.common.dto.InventoryEventDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class InventoryService {

    private final InventoryEventRepository inventoryEventRepository;

    public InventoryService(InventoryEventRepository inventoryEventRepository) {
        this.inventoryEventRepository = inventoryEventRepository;
    }

    public List<InventoryEventDto> recentEvents() {
        return inventoryEventRepository.findTop30ByOrderByCreatedAtDesc().stream()
                .map(InventoryEventMapper::toDto)
                .toList();
    }

    @Transactional
    public void recordBookAdded(Book book) {
        saveEvent(book, InventoryEvent.BOOK_ADDED, book.getStock(), book.getStock(), null);
    }

    @Transactional
    public void recordStockReserved(Book book, int quantity, Long orderId) {
        saveEvent(book, InventoryEvent.STOCK_RESERVED, -quantity, book.getStock(), orderId);
    }

    @Transactional
    public void recordStockReturned(Book book, int quantity, Long orderId) {
        saveEvent(book, InventoryEvent.STOCK_RETURNED, quantity, book.getStock(), orderId);
    }

    private void saveEvent(Book book, String eventType, int quantityChange, int stockAfter, Long orderId) {
        Store store = book.getStore();
        InventoryEvent event = new InventoryEvent();
        event.setBookId(book.getId());
        event.setBookTitle(book.getTitle());
        if (store != null) {
            event.setStoreId(store.getId());
            event.setStoreName(store.getName());
        }
        event.setEventType(eventType);
        event.setQuantityChange(quantityChange);
        event.setStockAfter(stockAfter);
        event.setOrderId(orderId);
        inventoryEventRepository.save(event);
    }
}
