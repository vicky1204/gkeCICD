package com.bookplatform.catalog.mapper;

import com.bookplatform.catalog.entity.Book;
import com.bookplatform.catalog.mapper.StoreMapper;
import com.bookplatform.common.dto.BookDto;

public final class BookMapper {

    private BookMapper() {}

    public static BookDto toDto(Book book) {
        return toDto(book, null, 0);
    }

    public static BookDto toDto(Book book, Double averageRating, int reviewCount) {
        return new BookDto(
                book.getId(),
                book.getTitle(),
                book.getAuthor(),
                book.getIsbn(),
                book.getPrice(),
                book.getCategory(),
                book.getDescription(),
                book.getStock(),
                book.getLanguage(),
                book.getImageUrl(),
                averageRating,
                reviewCount,
                StoreMapper.toDto(book.getStore())
        );
    }
}
