package com.bookplatform.catalog.mapper;

import com.bookplatform.catalog.entity.Review;
import com.bookplatform.common.dto.ReviewDto;

public final class ReviewMapper {

    private ReviewMapper() {}

    public static ReviewDto toDto(Review review) {
        return new ReviewDto(
                review.getId(),
                review.getBookId(),
                review.getUserId(),
                review.getUserFullName(),
                review.getRating(),
                review.getComment(),
                review.getCreatedAt()
        );
    }
}
