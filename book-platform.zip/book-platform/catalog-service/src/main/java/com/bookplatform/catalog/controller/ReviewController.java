package com.bookplatform.catalog.controller;

import com.bookplatform.catalog.service.ReviewService;
import com.bookplatform.common.dto.CreateReviewRequest;
import com.bookplatform.common.dto.ReviewDto;
import com.bookplatform.common.openapi.OpenApiConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books/{bookId}/reviews")
@Tag(name = "Reviews", description = "Book reviews and ratings")
public class ReviewController {

    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping
    public List<ReviewDto> list(@PathVariable("bookId") Long bookId) {
        return reviewService.getReviewsForBook(bookId);
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PostMapping
    public ResponseEntity<ReviewDto> create(@PathVariable("bookId") Long bookId,
                                          @Valid @RequestBody CreateReviewRequest request,
                                          Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        ReviewDto review = reviewService.upsertReview(bookId, userId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(review);
    }
}
