package com.bookplatform.catalog.repository;

import com.bookplatform.catalog.entity.InventoryEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InventoryEventRepository extends JpaRepository<InventoryEvent, Long> {

    List<InventoryEvent> findTop30ByOrderByCreatedAtDesc();
}
