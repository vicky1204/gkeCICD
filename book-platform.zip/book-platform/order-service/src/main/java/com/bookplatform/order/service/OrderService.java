package com.bookplatform.order.service;

import com.bookplatform.common.TermsAndConditions;
import com.bookplatform.common.client.CatalogServiceClient;
import com.bookplatform.common.client.UserServiceClient;
import com.bookplatform.common.dto.AdminDashboardResponse;
import com.bookplatform.common.dto.BookDto;
import com.bookplatform.common.dto.CheckoutRequest;
import com.bookplatform.common.dto.OrderResponse;
import com.bookplatform.common.dto.OrderStatus;
import com.bookplatform.common.dto.StoreDto;
import com.bookplatform.common.dto.StoreOrderSummary;
import com.bookplatform.common.dto.UserDto;
import com.bookplatform.common.event.OrderEvent;
import com.bookplatform.order.entity.Order;
import com.bookplatform.order.messaging.OrderEventPublisher;
import com.bookplatform.order.payment.PaymentBreakdown;
import com.bookplatform.order.payment.PaymentSplitStrategy;
import com.bookplatform.order.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final CatalogServiceClient catalogServiceClient;
    private final UserServiceClient userServiceClient;
    private final PaymentSplitStrategy paymentSplitStrategy;
    private final OrderEventPublisher eventPublisher;

    public OrderService(OrderRepository orderRepository,
                        CatalogServiceClient catalogServiceClient,
                        UserServiceClient userServiceClient,
                        PaymentSplitStrategy paymentSplitStrategy,
                        OrderEventPublisher eventPublisher) {
        this.orderRepository = orderRepository;
        this.catalogServiceClient = catalogServiceClient;
        this.userServiceClient = userServiceClient;
        this.paymentSplitStrategy = paymentSplitStrategy;
        this.eventPublisher = eventPublisher;
    }

    @Transactional
    public OrderResponse checkout(Long userId, CheckoutRequest request) {
        if (!request.termsAccepted()) {
            throw new IllegalArgumentException("You must accept Terms & Conditions");
        }

        UserDto user = userServiceClient.getUser(userId);
        BookDto book = catalogServiceClient.getBook(request.bookId());
        if (book.store() == null) {
            throw new IllegalStateException("Book is not linked to an offline store");
        }

        PaymentBreakdown payment = paymentSplitStrategy.calculate(book.price(), request.quantity());
        StoreDto store = book.store();

        Order order = new Order();
        order.setUserId(userId);
        order.setBookId(book.id());
        order.setBookTitle(book.title());
        order.setQuantity(request.quantity());
        order.setUnitPrice(book.price());
        order.setAmountPaid(payment.amountPaid());
        order.setTotalPlatformFee(payment.totalPlatformFee());
        order.setRefundAmount(payment.refundAmount());
        order.setStatus(OrderStatus.PAID);
        order.setStoreId(store.id());
        order.setStoreName(store.name());
        order.setStoreCity(store.city());
        order.setUserPhone(user.phone());
        order.setUserName(user.fullName());
        orderRepository.save(order);

        catalogServiceClient.reserveStock(request.bookId(), request.quantity(), order.getId());

        eventPublisher.publish(new OrderEvent(
                OrderEvent.ORDER_PLACED,
                order.getId(),
                userId,
                order.getUserPhone(),
                order.getUserName(),
                order.getBookTitle(),
                order.getQuantity(),
                order.getAmountPaid(),
                order.getRefundAmount(),
                Instant.now()
        ));

        return toResponse(order);
    }

    @Transactional
    public OrderResponse markDelivered(Long orderId) {
        Order order = requireOrder(orderId);
        if (OrderStatus.DELIVERED.equals(order.getStatus()) || OrderStatus.RETURNED.equals(order.getStatus())) {
            return toResponse(order);
        }
        if (!OrderStatus.PAID.equals(order.getStatus())) {
            throw new IllegalStateException("Only paid orders can be marked delivered");
        }
        order.setStatus(OrderStatus.DELIVERED);
        order.setDeliveredAt(Instant.now());
        orderRepository.save(order);

        eventPublisher.publish(new OrderEvent(
                OrderEvent.ORDER_DELIVERED,
                order.getId(),
                order.getUserId(),
                order.getUserPhone(),
                order.getUserName(),
                order.getBookTitle(),
                order.getQuantity(),
                order.getAmountPaid(),
                order.getRefundAmount(),
                Instant.now()
        ));

        return toResponse(order);
    }

    @Transactional
    public OrderResponse markReturned(Long orderId, Long userId, boolean isAdmin) {
        Order order = requireOrder(orderId);
        if (!isAdmin && !order.getUserId().equals(userId)) {
            throw new IllegalArgumentException("Access denied");
        }
        if (OrderStatus.RETURNED.equals(order.getStatus())) {
            return toResponse(order);
        }
        if (!OrderStatus.DELIVERED.equals(order.getStatus())) {
            throw new IllegalStateException("Book must be delivered before it can be returned to the store");
        }

        catalogServiceClient.releaseStock(order.getBookId(), order.getQuantity(), order.getId());
        order.setStatus(OrderStatus.RETURNED);
        order.setReturnedAt(Instant.now());
        orderRepository.save(order);

        eventPublisher.publish(new OrderEvent(
                OrderEvent.ORDER_RETURNED,
                order.getId(),
                order.getUserId(),
                order.getUserPhone(),
                order.getUserName(),
                order.getBookTitle(),
                order.getQuantity(),
                order.getAmountPaid(),
                order.getRefundAmount(),
                Instant.now()
        ));

        return toResponse(order);
    }

    public List<OrderResponse> getOrdersForUser(Long userId) {
        return orderRepository.findByUserIdOrderByCreatedAtDesc(userId)
                .stream().map(this::toResponse).toList();
    }

    public OrderResponse getOrder(Long orderId) {
        return toResponse(requireOrder(orderId));
    }

    public AdminDashboardResponse getAdminDashboard() {
        List<Order> orders = orderRepository.findAll();
        long paid = 0;
        long delivered = 0;
        long returned = 0;
        long booksWithReaders = 0;
        long booksBackAtStore = 0;
        long totalBooks = 0;
        BigDecimal revenue = BigDecimal.ZERO;
        BigDecimal refunds = BigDecimal.ZERO;

        Map<Long, StoreAccumulator> storeStats = new HashMap<>();

        for (Order order : orders) {
            totalBooks += order.getQuantity();
            revenue = revenue.add(order.getAmountPaid());
            switch (order.getStatus()) {
                case OrderStatus.PAID -> paid++;
                case OrderStatus.DELIVERED -> {
                    delivered++;
                    booksWithReaders += order.getQuantity();
                }
                case OrderStatus.RETURNED -> {
                    returned++;
                    booksBackAtStore += order.getQuantity();
                    refunds = refunds.add(order.getRefundAmount());
                }
                default -> { }
            }
            if (order.getStoreId() != null) {
                storeStats.computeIfAbsent(order.getStoreId(), id -> new StoreAccumulator(
                        order.getStoreId(), order.getStoreName(), order.getStoreCity()))
                        .add(order);
            }
        }

        List<StoreOrderSummary> summaries = storeStats.values().stream()
                .map(StoreAccumulator::toSummary)
                .sorted((a, b) -> a.storeName().compareToIgnoreCase(b.storeName()))
                .toList();

        List<OrderResponse> recent = orderRepository.findTop25ByOrderByCreatedAtDesc().stream()
                .map(this::toResponse)
                .toList();

        return new AdminDashboardResponse(
                orders.size(),
                totalBooks,
                paid,
                delivered,
                returned,
                booksWithReaders,
                booksBackAtStore,
                revenue,
                refunds,
                recent,
                summaries
        );
    }

    private Order requireOrder(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found"));
    }

    private OrderResponse toResponse(Order order) {
        return new OrderResponse(
                order.getId(),
                order.getUserId(),
                order.getBookId(),
                order.getBookTitle(),
                order.getQuantity(),
                order.getAmountPaid(),
                TermsAndConditions.platformFeeForUnitPrice(order.getUnitPrice()),
                order.getTotalPlatformFee(),
                order.getRefundAmount(),
                order.getStatus(),
                order.getStoreId(),
                order.getStoreName(),
                order.getStoreCity(),
                order.getCreatedAt(),
                order.getDeliveredAt(),
                order.getReturnedAt(),
                order.getUpdatedAt()
        );
    }

    private static final class StoreAccumulator {
        private final Long storeId;
        private final String storeName;
        private final String storeCity;
        private long totalOrders;
        private long booksWithReaders;
        private long booksReturned;
        private long booksAwaitingReturn;

        private StoreAccumulator(Long storeId, String storeName, String storeCity) {
            this.storeId = storeId;
            this.storeName = storeName;
            this.storeCity = storeCity;
        }

        private void add(Order order) {
            totalOrders++;
            if (OrderStatus.DELIVERED.equals(order.getStatus())) {
                booksWithReaders += order.getQuantity();
                booksAwaitingReturn += order.getQuantity();
            } else if (OrderStatus.RETURNED.equals(order.getStatus())) {
                booksReturned += order.getQuantity();
            } else if (OrderStatus.PAID.equals(order.getStatus())) {
                booksAwaitingReturn += order.getQuantity();
            }
        }

        private StoreOrderSummary toSummary() {
            return new StoreOrderSummary(
                    storeId, storeName, storeCity,
                    totalOrders, booksWithReaders, booksReturned, booksAwaitingReturn
            );
        }
    }
}
