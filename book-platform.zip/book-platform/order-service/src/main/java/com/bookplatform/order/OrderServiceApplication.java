package com.bookplatform.order;

import com.bookplatform.common.client.CatalogServiceClient;
import com.bookplatform.common.client.NotificationServiceClient;
import com.bookplatform.common.client.UserServiceClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = {"com.bookplatform.order", "com.bookplatform.common"})
@EnableFeignClients(clients = {UserServiceClient.class, CatalogServiceClient.class, NotificationServiceClient.class})
public class OrderServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
}
