package com.bookplatform.order.payment;

import java.math.BigDecimal;

/**
 * Strategy pattern: payment split — platform keeps 5 percent of book cost, rest is refundable.
 */
public interface PaymentSplitStrategy {
    PaymentBreakdown calculate(BigDecimal unitPrice, int quantity);
}
