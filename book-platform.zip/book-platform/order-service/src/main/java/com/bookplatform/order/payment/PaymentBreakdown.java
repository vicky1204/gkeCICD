package com.bookplatform.order.payment;

import java.math.BigDecimal;

public record PaymentBreakdown(
        BigDecimal amountPaid,
        BigDecimal platformFeePerBook,
        BigDecimal totalPlatformFee,
        BigDecimal refundAmount
) {
}
