package com.bookplatform.order.messaging;

import com.bookplatform.common.client.NotificationServiceClient;
import com.bookplatform.common.event.OrderEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class OrderEventPublisher {

    private static final Logger log = LoggerFactory.getLogger(OrderEventPublisher.class);

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final NotificationServiceClient notificationServiceClient;
    private final ObjectMapper objectMapper;
    private final boolean kafkaEnabled;

    public OrderEventPublisher(
            @Autowired(required = false) KafkaTemplate<String, String> kafkaTemplate,
            NotificationServiceClient notificationServiceClient,
            ObjectMapper objectMapper,
            @Value("${app.kafka.enabled:false}") boolean kafkaEnabled) {
        this.kafkaTemplate = kafkaTemplate;
        this.notificationServiceClient = notificationServiceClient;
        this.objectMapper = objectMapper;
        this.kafkaEnabled = kafkaEnabled;
    }

    public void publish(OrderEvent event) {
        try {
            if (kafkaEnabled && kafkaTemplate != null) {
                String json = objectMapper.writeValueAsString(event);
                kafkaTemplate.send("order-events", String.valueOf(event.orderId()), json);
                log.info("Published order event to Kafka: {}", event.eventType());
            } else {
                log.info("Kafka disabled — direct HTTP notify for {}", event.eventType());
                notificationServiceClient.publishOrderEvent(event);
            }
        } catch (Exception e) {
            log.error("Failed to publish order event", e);
        }
    }
}
