package com.bookplatform.order.controller;

import com.bookplatform.common.dto.AdminDashboardResponse;
import com.bookplatform.common.dto.CheckoutRequest;
import com.bookplatform.common.dto.OrderResponse;
import com.bookplatform.common.openapi.OpenApiConstants;
import com.bookplatform.order.service.OrderService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@Tag(name = "Orders", description = "Checkout, order history, delivery, and returns")
@SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/checkout")
    public ResponseEntity<OrderResponse> checkout(@Valid @RequestBody CheckoutRequest request,
                                                  Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        return ResponseEntity.ok(orderService.checkout(userId, request));
    }

    @GetMapping("/user/{userId}")
    public List<OrderResponse> userOrders(@PathVariable("userId") Long userId, Authentication authentication) {
        Long authenticatedUserId = (Long) authentication.getPrincipal();
        if (!authenticatedUserId.equals(userId)) {
            throw new IllegalArgumentException("Access denied");
        }
        return orderService.getOrdersForUser(userId);
    }

    @GetMapping("/{orderId}")
    public OrderResponse getOrder(@PathVariable("orderId") Long orderId) {
        return orderService.getOrder(orderId);
    }

    @PostMapping("/{orderId}/deliver")
    public ResponseEntity<OrderResponse> deliver(@PathVariable("orderId") Long orderId) {
        return ResponseEntity.ok(orderService.markDelivered(orderId));
    }

    @PostMapping("/{orderId}/return")
    public ResponseEntity<OrderResponse> returnToStore(@PathVariable("orderId") Long orderId,
                                                       Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        boolean isAdmin = isAdmin(authentication);
        return ResponseEntity.ok(orderService.markReturned(orderId, userId, isAdmin));
    }

    @GetMapping("/admin/dashboard")
    public AdminDashboardResponse adminDashboard(Authentication authentication) {
        requireAdmin(authentication);
        return orderService.getAdminDashboard();
    }

    private static boolean isAdmin(Authentication authentication) {
        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch("ROLE_ADMIN"::equals);
    }

    private static void requireAdmin(Authentication authentication) {
        if (!isAdmin(authentication)) {
            throw new IllegalArgumentException("Admin access required");
        }
    }
}
