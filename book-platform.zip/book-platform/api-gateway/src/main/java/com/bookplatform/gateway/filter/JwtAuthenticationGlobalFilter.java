package com.bookplatform.gateway.filter;

import com.bookplatform.common.security.JwtTokenProvider;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Component
public class JwtAuthenticationGlobalFilter implements GlobalFilter, Ordered {

    private static final AntPathMatcher PATH_MATCHER = new AntPathMatcher();

    private static final List<String> PUBLIC_POST_PATTERNS = List.of(
            "/api/users/register",
            "/api/users/login",
            "/api/users/reset-password"
    );

    private final JwtTokenProvider jwtTokenProvider;

    public JwtAuthenticationGlobalFilter(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path = exchange.getRequest().getPath().value();
        HttpMethod method = exchange.getRequest().getMethod();

        if (HttpMethod.OPTIONS.equals(method) || isPublic(path, method)) {
            return chain.filter(exchange);
        }

        String token = jwtTokenProvider.resolveBearerToken(
                exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION));
        if (token == null || !jwtTokenProvider.validate(token)) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
            byte[] body = "{\"title\":\"Unauthorized\",\"detail\":\"Valid Bearer token required\"}"
                    .getBytes(StandardCharsets.UTF_8);
            return exchange.getResponse().writeWith(Mono.just(exchange.getResponse()
                    .bufferFactory()
                    .wrap(body)));
        }

        return chain.filter(exchange);
    }

    private boolean isPublic(String path, HttpMethod method) {
        if (path.equals("/") || path.startsWith("/actuator")) {
            return true;
        }
        if (path.contains("/swagger-ui") || path.contains("/v3/api-docs")) {
            return true;
        }
        if (HttpMethod.GET.equals(method) && (PATH_MATCHER.match("/api/books", path)
                || PATH_MATCHER.match("/api/books/**", path)
                || PATH_MATCHER.match("/api/stores", path)
                || PATH_MATCHER.match("/api/stores/**", path))) {
            return true;
        }
        if (HttpMethod.POST.equals(method)) {
            return PUBLIC_POST_PATTERNS.stream().anyMatch(pattern -> PATH_MATCHER.match(pattern, path));
        }
        return false;
    }

    @Override
    public int getOrder() {
        return -100;
    }
}
