package com.bookplatform.gateway.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
public class GatewayIndexController {

    @GetMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<Map<String, Object>> index() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("service", "api-gateway");
        body.put("message", "Use the routes below. Swagger is proxied per service.");
        body.put("api", List.of(
                "/api/users/**",
                "/api/books/**",
                "/api/orders/**"
        ));
        body.put("swagger", Map.of(
                "user-service", "/user-service/swagger-ui/index.html",
                "catalog-service", "/catalog-service/swagger-ui/index.html",
                "order-service", "/order-service/swagger-ui/index.html",
                "notification-service", "/notification-service/swagger-ui/index.html",
                "legacy-redirect", "/api-gateway/swagger-ui/index.html"
        ));
        body.put("health", "/actuator/health");
        return Mono.just(body);
    }
}
