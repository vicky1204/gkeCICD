package com.bookplatform.common.dto;

import java.math.BigDecimal;

public record BookDto(
        Long id,
        String title,
        String author,
        String isbn,
        BigDecimal price,
        String category,
        String description,
        int stock,
        String language,
        String imageUrl,
        Double averageRating,
        int reviewCount,
        StoreDto store
) {
}
