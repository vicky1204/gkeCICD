package com.bookplatform.common.dto;

import java.time.Instant;

public record ReviewDto(
        Long id,
        Long bookId,
        Long userId,
        String userFullName,
        int rating,
        String comment,
        Instant createdAt
) {
}
