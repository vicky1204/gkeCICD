package com.bookplatform.common.dto;

public final class OrderStatus {

    public static final String PAID = "PAID";
    public static final String DELIVERED = "DELIVERED";
    public static final String RETURNED = "RETURNED";

    private OrderStatus() {
    }
}
