package com.bookplatform.common.client;

import com.bookplatform.common.config.FeignClientConfig;
import com.bookplatform.common.constants.ServiceNames;
import com.bookplatform.common.dto.AuthResponse;
import com.bookplatform.common.dto.LoginRequest;
import com.bookplatform.common.dto.ResetPasswordRequest;
import com.bookplatform.common.dto.UserDto;
import com.bookplatform.common.dto.UserRegistrationRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(
        name = ServiceNames.USER_SERVICE,
        url = "${bookplatform.services.user-url}",
        configuration = FeignClientConfig.class
)
public interface UserServiceClient {

    @PostMapping("/api/users/register")
    AuthResponse register(@RequestBody UserRegistrationRequest request);

    @PostMapping("/api/users/login")
    AuthResponse login(@RequestBody LoginRequest request);

    @PostMapping("/api/users/reset-password")
    void resetPassword(@RequestBody ResetPasswordRequest request);

    @GetMapping("/api/users/{id}")
    UserDto getUser(@PathVariable("id") Long id);
}
