package com.bookplatform.common.event;

import java.math.BigDecimal;
import java.time.Instant;

public record OrderEvent(
        String eventType,
        Long orderId,
        Long userId,
        String userPhone,
        String userName,
        String bookTitle,
        int quantity,
        BigDecimal amountPaid,
        BigDecimal refundAmount,
        Instant occurredAt
) {
    public static final String ORDER_PLACED = "ORDER_PLACED";
    public static final String ORDER_DELIVERED = "ORDER_DELIVERED";
    public static final String ORDER_RETURNED = "ORDER_RETURNED";
}
