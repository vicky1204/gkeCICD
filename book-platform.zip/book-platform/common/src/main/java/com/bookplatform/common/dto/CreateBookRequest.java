package com.bookplatform.common.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record CreateBookRequest(
        @NotBlank String title,
        @NotBlank String author,
        @NotBlank String isbn,
        @NotNull @DecimalMin("0.01") BigDecimal price,
        @NotBlank String category,
        @NotBlank String description,
        @Min(0) int stock,
        @NotBlank String language,
        @NotBlank String imageUrl,
        @NotNull Long storeId
) {
}
