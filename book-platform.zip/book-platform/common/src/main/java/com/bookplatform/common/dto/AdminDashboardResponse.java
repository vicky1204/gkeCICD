package com.bookplatform.common.dto;

import java.math.BigDecimal;
import java.util.List;

public record AdminDashboardResponse(
        long totalOrders,
        long totalBooksRented,
        long paidOrders,
        long deliveredOrders,
        long returnedOrders,
        long booksWithReaders,
        long booksBackAtStore,
        BigDecimal totalRevenue,
        BigDecimal totalRefundsProcessed,
        List<OrderResponse> recentOrders,
        List<StoreOrderSummary> storeSummaries
) {
}
