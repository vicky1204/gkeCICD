package com.bookplatform.common.dto;

public record StoreOrderSummary(
        Long storeId,
        String storeName,
        String storeCity,
        long totalOrders,
        long booksWithReaders,
        long booksReturned,
        long booksAwaitingReturn
) {
}
