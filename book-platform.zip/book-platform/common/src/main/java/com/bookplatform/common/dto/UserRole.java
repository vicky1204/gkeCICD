package com.bookplatform.common.dto;

public enum UserRole {
    USER,
    ADMIN
}
