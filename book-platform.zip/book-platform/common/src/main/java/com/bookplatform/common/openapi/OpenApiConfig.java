package com.bookplatform.common.openapi;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI bookPlatformOpenApi(@Value("${spring.application.name:book-platform}") String serviceName) {
        return new OpenAPI()
                .info(new Info()
                        .title(capitalizeServiceName(serviceName) + " API")
                        .description("Book Platform REST API. "
                                + "Obtain a JWT from user-service `POST /api/users/login`, "
                                + "then click **Authorize** and enter `Bearer <token>`.")
                        .version("1.0.0")
                        .contact(new Contact().name("Book Platform").email("support@bookplatform.local")))
                .components(new Components()
                        .addSecuritySchemes(OpenApiConstants.BEARER_AUTH, new SecurityScheme()
                                .name(OpenApiConstants.BEARER_AUTH)
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                                .description("JWT access token")));
    }

    private String capitalizeServiceName(String serviceName) {
        if (serviceName == null || serviceName.isBlank()) {
            return "Book Platform";
        }
        String[] parts = serviceName.split("-");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
            }
        }
        return sb.toString().trim();
    }
}
