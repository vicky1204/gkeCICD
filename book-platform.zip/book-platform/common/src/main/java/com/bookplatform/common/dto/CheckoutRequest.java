package com.bookplatform.common.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record CheckoutRequest(
        @NotNull Long bookId,
        @Min(1) int quantity,
        boolean termsAccepted
) {
}
