package com.bookplatform.common.dto;

import java.time.Instant;

public record InventoryEventDto(
        Long id,
        Long bookId,
        String bookTitle,
        Long storeId,
        String storeName,
        String eventType,
        int quantityChange,
        int stockAfter,
        Long orderId,
        Instant createdAt
) {
}
