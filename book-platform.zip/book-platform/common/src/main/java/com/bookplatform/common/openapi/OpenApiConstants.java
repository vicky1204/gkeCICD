package com.bookplatform.common.openapi;

public final class OpenApiConstants {

    public static final String BEARER_AUTH = "bearerAuth";

    public static final String[] SWAGGER_PATHS = {
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/*/v3/api-docs",
            "/*/v3/api-docs/**",
            "/*/swagger-ui.html",
            "/*/swagger-ui/**"
    };

    private OpenApiConstants() {
    }
}
