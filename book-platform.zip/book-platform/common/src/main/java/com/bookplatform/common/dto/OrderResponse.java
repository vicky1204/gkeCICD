package com.bookplatform.common.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record OrderResponse(
        Long orderId,
        Long userId,
        Long bookId,
        String bookTitle,
        int quantity,
        BigDecimal amountPaid,
        BigDecimal platformFeePerBook,
        BigDecimal totalPlatformFee,
        BigDecimal refundAmount,
        String status,
        Long storeId,
        String storeName,
        String storeCity,
        Instant placedAt,
        Instant deliveredAt,
        Instant returnedAt,
        Instant updatedAt
) {
}
