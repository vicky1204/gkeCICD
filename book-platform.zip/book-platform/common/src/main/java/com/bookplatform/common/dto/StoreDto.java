package com.bookplatform.common.dto;

public record StoreDto(
        Long id,
        String name,
        String contactPerson,
        String phone,
        String email,
        String addressLine,
        String city,
        String state,
        String pincode,
        String googleMapsUrl,
        String openingHours
) {
}
