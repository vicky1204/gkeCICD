package com.bookplatform.common.client;

import com.bookplatform.common.constants.ServiceNames;
import com.bookplatform.common.event.OrderEvent;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@FeignClient(name = ServiceNames.NOTIFICATION_SERVICE, url = "${bookplatform.services.notification-url}")
public interface NotificationServiceClient {

    @PostMapping("/api/notifications/order-event")
    Map<String, String> publishOrderEvent(@RequestBody OrderEvent event);
}
