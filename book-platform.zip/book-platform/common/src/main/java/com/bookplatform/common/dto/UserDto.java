package com.bookplatform.common.dto;

public record UserDto(
        Long id,
        String fullName,
        String email,
        String phone
) {
}
