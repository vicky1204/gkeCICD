package com.bookplatform.common.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class BookPageResponse {

    private final List<BookDto> content;
    private final int page;
    private final int size;
    private final long totalElements;
    private final int totalPages;
    private final List<String> categories;
    private final List<String> languages;

    @JsonCreator
    public BookPageResponse(
            @JsonProperty("content") List<BookDto> content,
            @JsonProperty("page") int page,
            @JsonProperty("size") int size,
            @JsonProperty("totalElements") long totalElements,
            @JsonProperty("totalPages") int totalPages,
            @JsonProperty("categories") List<String> categories,
            @JsonProperty("languages") List<String> languages) {
        this.content = content != null ? content : List.of();
        this.page = page;
        this.size = size;
        this.totalElements = totalElements;
        this.totalPages = totalPages;
        this.categories = categories != null ? categories : List.of();
        this.languages = languages != null ? languages : List.of();
    }

    public List<BookDto> getContent() {
        return content;
    }

    public int getPage() {
        return page;
    }

    public int getSize() {
        return size;
    }

    public long getTotalElements() {
        return totalElements;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public List<String> getCategories() {
        return categories;
    }

    public List<String> getLanguages() {
        return languages;
    }
}
