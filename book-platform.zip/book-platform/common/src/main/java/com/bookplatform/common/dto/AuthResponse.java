package com.bookplatform.common.dto;

public record AuthResponse(
        String token,
        Long userId,
        String fullName,
        String email,
        String phone,
        UserRole role
) implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    public boolean isAdmin() {
        return role == UserRole.ADMIN;
    }
}
