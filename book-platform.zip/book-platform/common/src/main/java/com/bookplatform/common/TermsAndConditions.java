package com.bookplatform.common;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class TermsAndConditions {

    public static final String TEXT = """
            BOOK PLATFORM — TERMS & CONDITIONS

            1. Registration is mandatory before purchase.
            2. You pay the listed book price at checkout.
            3. Platform service fee: 5% of price of book (non-refundable).
            4. Remaining amount is refunded after successful delivery when the book is returned in good condition.
            5. Books must NOT be torn, water-damaged, or defaced.
            6. Returns must be in the same condition as received.
            7. Refund is processed only after quality check on return.
            8. By checking "I accept", you agree to these terms.
            """;

    public static final BigDecimal PLATFORM_FEE_PERCENT = new BigDecimal("5");

    private static final BigDecimal HUNDRED = new BigDecimal("100");

    private TermsAndConditions() {
    }

    public static BigDecimal platformFeeForUnitPrice(BigDecimal unitPrice) {
        if (unitPrice == null) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
        return unitPrice.multiply(PLATFORM_FEE_PERCENT)
                .divide(HUNDRED, 2, RoundingMode.HALF_UP);
    }

    public static BigDecimal refundForUnitPrice(BigDecimal unitPrice) {
        if (unitPrice == null) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
        return unitPrice.subtract(platformFeeForUnitPrice(unitPrice));
    }
}
