package com.bookplatform.common.client;

import com.bookplatform.common.config.FeignClientConfig;
import com.bookplatform.common.constants.ServiceNames;
import com.bookplatform.common.dto.AdminDashboardResponse;
import com.bookplatform.common.dto.CheckoutRequest;
import com.bookplatform.common.dto.OrderResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(
        name = ServiceNames.ORDER_SERVICE,
        url = "${bookplatform.services.order-url}",
        configuration = FeignClientConfig.class
)
public interface OrderServiceClient {

    @PostMapping("/api/orders/checkout")
    OrderResponse checkout(@RequestBody CheckoutRequest request);

    @GetMapping("/api/orders/user/{userId}")
    List<OrderResponse> userOrders(@PathVariable("userId") Long userId);

    @PostMapping("/api/orders/{orderId}/deliver")
    OrderResponse deliverOrder(@PathVariable("orderId") Long orderId);

    @PostMapping("/api/orders/{orderId}/return")
    OrderResponse returnOrder(@PathVariable("orderId") Long orderId);

    @GetMapping("/api/orders/admin/dashboard")
    AdminDashboardResponse adminDashboard();
}
