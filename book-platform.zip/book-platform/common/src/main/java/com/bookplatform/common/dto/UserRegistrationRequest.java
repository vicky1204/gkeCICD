package com.bookplatform.common.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UserRegistrationRequest(
        @NotBlank String fullName,
        @NotBlank @Email String email,
        @NotBlank @Size(min = 6, max = 100) String password,
        @NotBlank
        @Pattern(regexp = "^\\+?[0-9]{10,15}$", message = "Valid WhatsApp phone number required")
        String phone
) {
}
