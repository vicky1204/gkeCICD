package com.bookplatform.common.constants;

/**
 * Kubernetes service names and ports for the book-platform namespace.
 * DNS inside the cluster: {@code http://<service-name>:<port>}
 */
public final class ServiceNames {

    public static final String NAMESPACE = "book-platform";

    public static final String USER_SERVICE = "user-service";
    public static final String CATALOG_SERVICE = "catalog-service";
    public static final String ORDER_SERVICE = "order-service";
    public static final String NOTIFICATION_SERVICE = "notification-service";
    public static final String API_GATEWAY = "api-gateway";
    public static final String WEB_UI = "web-ui";

    public static final int USER_PORT = 8081;
    public static final int CATALOG_PORT = 8082;
    public static final int ORDER_PORT = 8083;
    public static final int NOTIFICATION_PORT = 8084;
    public static final int GATEWAY_PORT = 8080;
    public static final int WEB_UI_PORT = 8090;

    private ServiceNames() {
    }

    public static String k8sUrl(String serviceName, int port) {
        return "http://" + serviceName + ":" + port;
    }
}
