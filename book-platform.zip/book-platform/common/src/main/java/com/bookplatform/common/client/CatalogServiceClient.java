package com.bookplatform.common.client;

import com.bookplatform.common.config.FeignClientConfig;
import com.bookplatform.common.constants.ServiceNames;
import com.bookplatform.common.dto.BookDto;
import com.bookplatform.common.dto.BookPageResponse;
import com.bookplatform.common.dto.CreateBookRequest;
import com.bookplatform.common.dto.CreateReviewRequest;
import com.bookplatform.common.dto.InventoryEventDto;
import com.bookplatform.common.dto.ReviewDto;
import com.bookplatform.common.dto.StoreDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@FeignClient(
        name = ServiceNames.CATALOG_SERVICE,
        url = "${bookplatform.services.catalog-url}",
        configuration = FeignClientConfig.class
)
public interface CatalogServiceClient {

    @GetMapping("/api/books")
    BookPageResponse searchBooks(@RequestParam(value = "q", required = false) String q,
                                 @RequestParam(value = "category", required = false) String category,
                                 @RequestParam(value = "language", required = false) String language,
                                 @RequestParam(value = "page", defaultValue = "0") int page,
                                 @RequestParam(value = "size", defaultValue = "50") int size);

    @GetMapping("/api/books/recommended")
    List<BookDto> getRecommendedBooks(@RequestParam(value = "limit", defaultValue = "6") int limit);

    @GetMapping("/api/books/{id}")
    BookDto getBook(@PathVariable("id") Long id);

    @PostMapping("/api/books")
    BookDto createBook(@RequestBody CreateBookRequest request);

    @PostMapping("/api/books/{id}/reserve")
    Map<String, String> reserveStock(@PathVariable("id") Long bookId,
                                     @RequestParam("quantity") int quantity,
                                     @RequestParam(value = "orderId", required = false) Long orderId);

    @PostMapping("/api/books/{id}/release")
    Map<String, String> releaseStock(@PathVariable("id") Long bookId,
                                     @RequestParam("quantity") int quantity,
                                     @RequestParam(value = "orderId", required = false) Long orderId);

    @GetMapping("/api/inventory/events")
    List<InventoryEventDto> recentInventoryEvents();

    @GetMapping("/api/books/{bookId}/reviews")
    List<ReviewDto> getReviews(@PathVariable("bookId") Long bookId);

    @PostMapping("/api/books/{bookId}/reviews")
    ReviewDto createReview(@PathVariable("bookId") Long bookId, @RequestBody CreateReviewRequest request);

    @GetMapping("/api/stores")
    List<StoreDto> listStores();

    @GetMapping("/api/stores/{id}")
    StoreDto getStore(@PathVariable("id") Long id);
}
