package com.bookplatform.notification.whatsapp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Factory / Strategy: mock implementation for local dev.
 * Replace with TwilioWhatsAppNotifier in production (see README).
 */
@Component
@ConditionalOnProperty(name = "whatsapp.provider", havingValue = "mock", matchIfMissing = true)
public class MockWhatsAppNotifier implements WhatsAppNotifier {

    private static final Logger log = LoggerFactory.getLogger(MockWhatsAppNotifier.class);

    @Override
    public void send(String phone, String message) {
        log.info("========== WHATSAPP MOCK ==========");
        log.info("To: {}", phone);
        log.info("Message: {}", message);
        log.info("=================================");
    }
}
