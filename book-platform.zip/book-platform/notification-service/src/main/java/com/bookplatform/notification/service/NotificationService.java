package com.bookplatform.notification.service;

import com.bookplatform.common.event.OrderEvent;
import com.bookplatform.notification.whatsapp.WhatsAppNotifier;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    private final WhatsAppNotifier whatsAppNotifier;

    public NotificationService(WhatsAppNotifier whatsAppNotifier) {
        this.whatsAppNotifier = whatsAppNotifier;
    }

    public void handleOrderEvent(OrderEvent event) {
        String message = buildMessage(event);
        whatsAppNotifier.send(event.userPhone(), message);
    }

    private String buildMessage(OrderEvent event) {
        if (OrderEvent.ORDER_DELIVERED.equals(event.eventType())) {
            return String.format(
                    "Hi %s! Your book '%s' (qty %d) has been DELIVERED. " +
                    "Amount paid: INR %s. Platform fee: 5 percent of book cost x %d. " +
                    "Refundable amount (after good return): INR %s. " +
                    "Please return the book in good condition (not torn).",
                    event.userName(),
                    event.bookTitle(),
                    event.quantity(),
                    event.amountPaid(),
                    event.quantity(),
                    event.refundAmount()
            );
        }
        if (OrderEvent.ORDER_RETURNED.equals(event.eventType())) {
            return String.format(
                    "Hi %s! Your book '%s' (qty %d) was RETURNED to the store in good condition. " +
                    "Refund of INR %s has been processed. Thank you for sharing the read!",
                    event.userName(),
                    event.bookTitle(),
                    event.quantity(),
                    event.refundAmount()
            );
        }
        return String.format(
                "Hi %s! Order #%d confirmed for '%s' (qty %d). " +
                "Paid: INR %s. Refund after return: INR %s.",
                event.userName(),
                event.orderId(),
                event.bookTitle(),
                event.quantity(),
                event.amountPaid(),
                event.refundAmount()
        );
    }
}
