package com.bookplatform.notification.controller;

import com.bookplatform.common.event.OrderEvent;
import com.bookplatform.notification.service.NotificationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@Tag(name = "Notifications", description = "Order event notifications (internal / Kafka fallback)")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @PostMapping("/order-event")
    public ResponseEntity<Map<String, String>> orderEvent(@RequestBody OrderEvent event) {
        notificationService.handleOrderEvent(event);
        return ResponseEntity.ok(Map.of("status", "SENT"));
    }
}
