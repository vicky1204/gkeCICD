package com.bookplatform.notification.whatsapp;

public interface WhatsAppNotifier {
    void send(String phone, String message);
}
