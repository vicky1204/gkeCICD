package com.bookplatform.web.config;

import com.bookplatform.web.controller.WebController;
import com.bookplatform.web.support.ErrorMessages;
import com.bookplatform.web.support.ErrorRedirect;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice(assignableTypes = WebController.class)
public class WebUiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(WebUiExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public String handleException(Exception ex,
                                  HttpServletRequest request,
                                  RedirectAttributes redirectAttributes,
                                  Model model) {
        log.error("Unhandled web-ui error on {}", request.getRequestURI(), ex);
        if (request.getRequestURI().startsWith("/error")) {
            model.addAttribute("errorTitle", ErrorMessages.titleFor(ex));
            model.addAttribute("errorMessage", ErrorMessages.resolve(ex));
            model.addAttribute("errorHint", ErrorMessages.hintFor(ex));
            model.addAttribute("returnUrl", "/login");
            model.addAttribute("returnLabel", "Go to login");
            return "error";
        }
        return ErrorRedirect.toErrorPage(
                redirectAttributes,
                ex,
                safeReturnPath(request),
                "Go back"
        );
    }

    private String safeReturnPath(HttpServletRequest request) {
        String path = request.getRequestURI();
        if (path != null && !path.startsWith("/error")) {
            return path;
        }
        String referer = request.getHeader("Referer");
        if (referer != null && referer.contains(request.getServerName())) {
            try {
                var uri = java.net.URI.create(referer);
                String refererPath = uri.getPath();
                if (refererPath != null && !refererPath.startsWith("/error")) {
                    return refererPath;
                }
            } catch (IllegalArgumentException ignored) {
                // use default
            }
        }
        return "/login";
    }
}
