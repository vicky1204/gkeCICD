package com.bookplatform.web;

import com.bookplatform.common.client.CatalogServiceClient;
import com.bookplatform.common.client.OrderServiceClient;
import com.bookplatform.common.client.UserServiceClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = {"com.bookplatform.web", "com.bookplatform.common"})
@EnableFeignClients(clients = {UserServiceClient.class, CatalogServiceClient.class, OrderServiceClient.class})
public class WebUiApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebUiApplication.class, args);
    }
}
