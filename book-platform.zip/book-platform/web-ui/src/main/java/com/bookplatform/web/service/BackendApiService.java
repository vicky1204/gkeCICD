package com.bookplatform.web.service;

import com.bookplatform.common.client.CatalogServiceClient;
import com.bookplatform.common.client.OrderServiceClient;
import com.bookplatform.common.client.UserServiceClient;
import com.bookplatform.common.dto.*;
import com.bookplatform.common.security.AuthTokenHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Supplier;

@Service
public class BackendApiService {

    private final UserServiceClient userServiceClient;
    private final CatalogServiceClient catalogServiceClient;
    private final OrderServiceClient orderServiceClient;

    public BackendApiService(UserServiceClient userServiceClient,
                             CatalogServiceClient catalogServiceClient,
                             OrderServiceClient orderServiceClient) {
        this.userServiceClient = userServiceClient;
        this.catalogServiceClient = catalogServiceClient;
        this.orderServiceClient = orderServiceClient;
    }

    public AuthResponse register(UserRegistrationRequest request) {
        return userServiceClient.register(request);
    }

    public AuthResponse login(LoginRequest request) {
        return userServiceClient.login(request);
    }

    public void resetPassword(ResetPasswordRequest request) {
        userServiceClient.resetPassword(request);
    }

    public BookPageResponse browseBooks(String query,
                                        String category,
                                        String language,
                                        int page,
                                        String token) {
        return withToken(token, () -> catalogServiceClient.searchBooks(query, category, language, page, 50));
    }

    public List<BookDto> getRecommendedBooks(int limit, String token) {
        return withToken(token, () -> catalogServiceClient.getRecommendedBooks(limit));
    }

    public BookDto getBook(Long id, String token) {
        return withToken(token, () -> catalogServiceClient.getBook(id));
    }

    public List<ReviewDto> getReviews(Long bookId, String token) {
        return withToken(token, () -> catalogServiceClient.getReviews(bookId));
    }

    public ReviewDto submitReview(Long bookId, CreateReviewRequest request, String token) {
        return withToken(token, () -> catalogServiceClient.createReview(bookId, request));
    }

    public List<StoreDto> listStores(String token) {
        return withToken(token, () -> catalogServiceClient.listStores());
    }

    public BookDto createBook(CreateBookRequest request, String token) {
        return withToken(token, () -> catalogServiceClient.createBook(request));
    }

    public OrderResponse checkout(Long userId, CheckoutRequest request, String token) {
        return withToken(token, () -> orderServiceClient.checkout(request));
    }

    public List<OrderResponse> userOrders(Long userId, String token) {
        return withToken(token, () -> orderServiceClient.userOrders(userId));
    }

    public OrderResponse deliverOrder(Long orderId, String token) {
        return withToken(token, () -> orderServiceClient.deliverOrder(orderId));
    }

    public OrderResponse returnOrder(Long orderId, String token) {
        return withToken(token, () -> orderServiceClient.returnOrder(orderId));
    }

    public AdminDashboardResponse getAdminDashboard(String token) {
        return withToken(token, () -> orderServiceClient.adminDashboard());
    }

    public List<InventoryEventDto> getRecentInventoryEvents(String token) {
        return withToken(token, () -> catalogServiceClient.recentInventoryEvents());
    }

    private <T> T withToken(String token, Supplier<T> action) {
        if (token == null || token.isBlank()) {
            return action.get();
        }
        try {
            AuthTokenHolder.set(token);
            return action.get();
        } finally {
            AuthTokenHolder.clear();
        }
    }
}
