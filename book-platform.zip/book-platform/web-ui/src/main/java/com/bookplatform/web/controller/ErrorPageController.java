package com.bookplatform.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/error")
public class ErrorPageController implements ErrorController {

    @GetMapping
    public String errorPage(Model model,
                            HttpServletRequest request,
                            @RequestParam(value = "returnUrl", defaultValue = "/login") String returnUrl,
                            @RequestParam(value = "returnLabel", defaultValue = "Go back") String returnLabel) {
        if (!model.containsAttribute("errorTitle")) {
            model.addAttribute("errorTitle", resolveTitle(request));
        }
        if (!model.containsAttribute("errorMessage")) {
            model.addAttribute("errorMessage", resolveMessage(request));
        }
        if (!model.containsAttribute("errorHint")) {
            model.addAttribute("errorHint", resolveHint(request));
        }
        if (!model.containsAttribute("returnUrl")) {
            model.addAttribute("returnUrl", returnUrl);
        }
        if (!model.containsAttribute("returnLabel")) {
            model.addAttribute("returnLabel", returnLabel);
        }
        return "error";
    }

    private String resolveTitle(HttpServletRequest request) {
        Integer status = statusCode(request);
        if (status != null && status == 404) {
            return "Page not found";
        }
        if (status != null && status >= 500) {
            return "Server error";
        }
        return "Something went wrong";
    }

    private String resolveMessage(HttpServletRequest request) {
        Object message = request.getAttribute("javax.servlet.error.message");
        if (message != null && !message.toString().isBlank()) {
            return message.toString();
        }
        Integer status = statusCode(request);
        if (status != null && status == 404) {
            return "The page you requested does not exist.";
        }
        if (status != null && status >= 500) {
            return "An unexpected error occurred. Please try again or return to the login page.";
        }
        return "An unexpected error occurred. Please try again.";
    }

    private String resolveHint(HttpServletRequest request) {
        Integer status = statusCode(request);
        if (status != null && status >= 500) {
            return "If this keeps happening, ensure user-service (8081), catalog-service (8082), and order-service (8083) are running.";
        }
        return null;
    }

    private Integer statusCode(HttpServletRequest request) {
        Object status = request.getAttribute("javax.servlet.error.status_code");
        if (status instanceof Integer code) {
            return code;
        }
        if (status instanceof String s) {
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        return null;
    }
}
