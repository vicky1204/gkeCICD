package com.bookplatform.web.support;

import feign.FeignException;

public final class ErrorMessages {

    private ErrorMessages() {
    }

    public static String resolve(Throwable ex) {
        Throwable root = ex;
        while (root.getCause() != null && root.getCause() != root) {
            root = root.getCause();
        }

        String msg = ex.getMessage() == null ? "" : ex.getMessage();

        if (ex instanceof FeignException feign) {
            return resolveFeign(feign);
        }

        if (isConnectionIssue(msg, root)) {
            return "We could not reach the backend services. "
                    + "Please start user-service (8081), catalog-service (8082), and order-service (8083), then try again.";
        }

        if (isCircuitBreakerOrFallbackIssue(msg, root)) {
            return "A backend service is temporarily unavailable. "
                    + "Ensure catalog-service (8082) is running, then restart web-ui and try again.";
        }

        String detail = extractDetail(msg);
        if (detail != null) {
            return detail;
        }

        if (!msg.isBlank()) {
            return msg;
        }

        return "Something went wrong. Please try again in a moment.";
    }

    public static String titleFor(Throwable ex) {
        if (isConnectionIssue(ex.getMessage(), ex)) {
            return "Services unavailable";
        }
        if (ex instanceof FeignException feign) {
            if (feign.status() == 401 || feign.status() == 403) {
                return "Sign in required";
            }
            if (feign.status() == 400) {
                return "Request could not be completed";
            }
            if (feign.status() >= 500) {
                return "Server error";
            }
        }
        return "Something went wrong";
    }

    public static String hintFor(Throwable ex) {
        if (isConnectionIssue(ex.getMessage(), ex)) {
            return "Tip: run .\\scripts\\start-all.ps1 or start each service in its own terminal.";
        }
        if (ex instanceof FeignException feign && feign.status() >= 500) {
            return "Check the service logs in your IDE or terminal for more details.";
        }
        return null;
    }

    public static boolean isServiceUnavailable(Throwable ex) {
        if (isConnectionIssue(ex.getMessage(), ex)) {
            return true;
        }
        return ex instanceof FeignException feign && feign.status() >= 500;
    }

    private static String resolveFeign(FeignException feign) {
        if (feign.status() == 401 || feign.status() == 403) {
            return feign.status() == 403
                    ? "You do not have permission to perform this action."
                    : "Your session has expired or your credentials are invalid. Please sign in again.";
        }
        if (feign.status() == 400) {
            String detail = extractDetail(feign.getMessage());
            return detail != null ? detail : "Please check your input and try again.";
        }
        if (feign.status() == 404) {
            return "The requested resource was not found.";
        }
        if (feign.status() >= 500) {
            return "A backend service encountered an error. Ensure all microservices are running.";
        }
        return "The request could not be completed. Please try again.";
    }

    private static boolean isConnectionIssue(String msg, Throwable root) {
        for (Throwable t = root; t != null; t = t.getCause()) {
            String current = t.getMessage() == null ? "" : t.getMessage();
            if (current.contains("Connection refused")
                    || current.contains("Failed to connect")
                    || current.contains("Connection timed out")
                    || current.contains("I/O error")) {
                return true;
            }
            if (t.getClass().getSimpleName().contains("Connect")) {
                return true;
            }
        }
        if (msg != null && (msg.contains("Connection refused")
                || msg.contains("Failed to connect")
                || msg.contains("Connection timed out")
                || msg.contains("I/O error"))) {
            return true;
        }
        return false;
    }

    private static boolean isCircuitBreakerOrFallbackIssue(String msg, Throwable root) {
        if (msg.contains("No fallback available")) {
            return true;
        }
        for (Throwable t = root; t != null; t = t.getCause()) {
            String name = t.getClass().getSimpleName();
            if (name.contains("CallNotPermitted")
                    || name.contains("NoFallbackAvailable")
                    || name.contains("CircuitBreaker")) {
                return true;
            }
            String current = t.getMessage();
            if (current != null && current.contains("No fallback available")) {
                return true;
            }
        }
        return false;
    }

    private static String extractDetail(String message) {
        if (message == null || !message.contains("detail")) {
            return null;
        }
        int start = message.indexOf("\"detail\":\"");
        if (start < 0) {
            return null;
        }
        start += 10;
        int end = message.indexOf('"', start);
        if (end > start) {
            return message.substring(start, end);
        }
        return null;
    }
}
