package com.bookplatform.web.support;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

public final class ErrorRedirect {

    private ErrorRedirect() {
    }

    public static String toErrorPage(RedirectAttributes redirectAttributes,
                                     Throwable ex,
                                     String returnUrl,
                                     String returnLabel) {
        if ("/".equals(returnUrl) || "/error".equals(returnUrl)) {
            returnUrl = "/login";
            returnLabel = "Go to login";
        }
        redirectAttributes.addFlashAttribute("errorTitle", ErrorMessages.titleFor(ex));
        redirectAttributes.addFlashAttribute("errorMessage", ErrorMessages.resolve(ex));
        redirectAttributes.addFlashAttribute("errorHint", ErrorMessages.hintFor(ex));
        redirectAttributes.addFlashAttribute("returnUrl", returnUrl);
        redirectAttributes.addFlashAttribute("returnLabel", returnLabel);
        return "redirect:/error";
    }

    public static String toErrorPage(RedirectAttributes redirectAttributes,
                                     String title,
                                     String message,
                                     String hint,
                                     String returnUrl,
                                     String returnLabel) {
        redirectAttributes.addFlashAttribute("errorTitle", title);
        redirectAttributes.addFlashAttribute("errorMessage", message);
        redirectAttributes.addFlashAttribute("errorHint", hint);
        redirectAttributes.addFlashAttribute("returnUrl", returnUrl);
        redirectAttributes.addFlashAttribute("returnLabel", returnLabel);
        return "redirect:/error";
    }
}
