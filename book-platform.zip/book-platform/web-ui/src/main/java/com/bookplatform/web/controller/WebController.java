package com.bookplatform.web.controller;

import com.bookplatform.common.TermsAndConditions;
import com.bookplatform.common.dto.*;
import com.bookplatform.web.service.BackendApiService;
import com.bookplatform.web.support.ErrorMessages;
import com.bookplatform.web.support.ErrorRedirect;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@Controller
public class WebController {

    private static final Logger log = LoggerFactory.getLogger(WebController.class);

    private final BackendApiService backendApi;

    public WebController(BackendApiService backendApi) {
        this.backendApi = backendApi;
    }

    @GetMapping("/")
    public String home(@RequestParam(value = "q", required = false) String q,
                       @RequestParam(value = "category", required = false) String category,
                       @RequestParam(value = "language", required = false) String language,
                       @RequestParam(value = "page", defaultValue = "0") int page,
                       HttpSession session,
                       Model model) {
        AuthResponse user = currentUser(session);
        if (user == null) {
            return "redirect:/login";
        }
        model.addAttribute("user", user);
        model.addAttribute("isAdmin", user.isAdmin());
        model.addAttribute("query", q == null ? "" : q);
        model.addAttribute("selectedCategory", category == null ? "" : category);
        model.addAttribute("selectedLanguage", language == null ? "" : language);
        boolean showRecommended = page == 0
                && (q == null || q.isBlank())
                && (category == null || category.isBlank())
                && (language == null || language.isBlank());
        model.addAttribute("showRecommended", showRecommended);
        try {
            BookPageResponse bookPage = backendApi.browseBooks(q, category, language, page, user.token());
            model.addAttribute("bookPage", bookPage);
            model.addAttribute("books", bookPage.getContent());
            model.addAttribute("categories", bookPage.getCategories());
            model.addAttribute("languages", bookPage.getLanguages());
            if (showRecommended) {
                model.addAttribute("recommendedBooks", backendApi.getRecommendedBooks(6, user.token()));
            } else {
                model.addAttribute("recommendedBooks", Collections.emptyList());
            }
        } catch (Exception e) {
            log.warn("Failed to load books from catalog-service", e);
            model.addAttribute("bookPage", new BookPageResponse(Collections.emptyList(), 0, 50, 0, 0,
                    Collections.emptyList(), Collections.emptyList()));
            model.addAttribute("books", Collections.emptyList());
            model.addAttribute("categories", Collections.emptyList());
            model.addAttribute("languages", Collections.emptyList());
            model.addAttribute("recommendedBooks", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "home";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("email") String email,
                        @RequestParam("password") String password,
                        HttpSession session,
                        RedirectAttributes redirectAttributes) {
        try {
            AuthResponse auth = backendApi.login(new LoginRequest(email, password));
            session.setAttribute("user", auth);
            return "redirect:/";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/login", "Try again");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/login";
        }
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam("fullName") String fullName,
                           @RequestParam("email") String email,
                           @RequestParam("password") String password,
                           @RequestParam("phone") String phone,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        try {
            AuthResponse auth = backendApi.register(new UserRegistrationRequest(fullName, email, password, phone));
            session.setAttribute("user", auth);
            return "redirect:/";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/register", "Try again");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/register";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/forgot-password")
    public String forgotPasswordPage() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String resetPassword(@RequestParam("email") String email,
                                @RequestParam("newPassword") String newPassword,
                                @RequestParam("confirmPassword") String confirmPassword,
                                RedirectAttributes redirectAttributes) {
        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Passwords do not match");
            return "redirect:/forgot-password";
        }
        if (newPassword.length() < 6) {
            redirectAttributes.addFlashAttribute("error", "Password must be at least 6 characters");
            return "redirect:/forgot-password";
        }
        try {
            backendApi.resetPassword(new ResetPasswordRequest(email, newPassword));
            redirectAttributes.addFlashAttribute("success", "Password updated. You can sign in now.");
            return "redirect:/login";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/forgot-password", "Try again");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/forgot-password";
        }
    }

    @GetMapping("/books/{id}")
    public String bookDetail(@PathVariable("id") Long id,
                             HttpSession session,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto book = backendApi.getBook(id, user.token());
            List<ReviewDto> reviews = backendApi.getReviews(id, user.token());
            ReviewDto userReview = reviews.stream()
                    .filter(review -> review.userId().equals(user.userId()))
                    .findFirst()
                    .orElse(null);

            model.addAttribute("user", user);
            model.addAttribute("isAdmin", user.isAdmin());
            model.addAttribute("book", book);
            model.addAttribute("reviews", reviews);
            model.addAttribute("userReview", userReview);
            return "book-detail";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to books");
            }
            return ErrorRedirect.toErrorPage(
                    redirectAttributes,
                    "Book unavailable",
                    ErrorMessages.resolve(e),
                    null,
                    "/",
                    "Back to books"
            );
        }
    }

    @PostMapping("/books/{id}/reviews")
    public String submitReview(@PathVariable("id") Long id,
                               @RequestParam("rating") int rating,
                               @RequestParam(value = "comment", required = false) String comment,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            backendApi.submitReview(id,
                    new CreateReviewRequest(rating, comment == null ? "" : comment, user.fullName()),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Your review has been saved.");
            return "redirect:/books/" + id;
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/books/" + id, "Back to book");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/books/" + id;
        }
    }

    @GetMapping("/books/{id}/checkout")
    public String checkoutPage(@PathVariable("id") Long id,
                               HttpSession session,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto book = backendApi.getBook(id, user.token());
            BigDecimal platformFee = TermsAndConditions.platformFeeForUnitPrice(book.price());
            BigDecimal refundPreview = TermsAndConditions.refundForUnitPrice(book.price());

            model.addAttribute("user", user);
            model.addAttribute("isAdmin", user.isAdmin());
            model.addAttribute("book", book);
            model.addAttribute("terms", TermsAndConditions.TEXT);
            model.addAttribute("platformFee", platformFee);
            model.addAttribute("refundPreview", refundPreview.max(BigDecimal.ZERO));
            return "checkout";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to books");
            }
            return ErrorRedirect.toErrorPage(
                    redirectAttributes,
                    "Book unavailable",
                    ErrorMessages.resolve(e),
                    null,
                    "/",
                    "Back to books"
            );
        }
    }

    @PostMapping("/books/{id}/checkout")
    public String checkout(@PathVariable("id") Long id,
                           @RequestParam("quantity") int quantity,
                           @RequestParam(value = "termsAccepted", required = false) Boolean termsAccepted,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            boolean accepted = termsAccepted != null && termsAccepted;
            OrderResponse order = backendApi.checkout(user.userId(),
                    new CheckoutRequest(id, quantity, accepted), user.token());
            redirectAttributes.addFlashAttribute("success",
                    "Order placed! Paid INR " + order.amountPaid() + ". Refund after return: INR " + order.refundAmount());
            return "redirect:/orders";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/books/" + id + "/checkout", "Back to checkout");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/books/" + id + "/checkout";
        }
    }

    @GetMapping("/orders")
    public String orders(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        model.addAttribute("user", user);
        model.addAttribute("isAdmin", user.isAdmin());
        try {
            model.addAttribute("orders", backendApi.userOrders(user.userId(), user.token()));
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/orders", "Try again");
            }
            model.addAttribute("orders", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "orders";
    }

    @PostMapping("/orders/{orderId}/deliver")
    public String deliver(@PathVariable("orderId") Long orderId,
                          HttpSession session,
                          RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            backendApi.deliverOrder(orderId, user.token());
            redirectAttributes.addFlashAttribute("success",
                    "Order marked DELIVERED. WhatsApp notification sent (check notification-service logs).");
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/orders", "Back to orders");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
        }
        return "redirect:/orders";
    }

    @PostMapping("/orders/{orderId}/return")
    public String returnOrder(@PathVariable("orderId") Long orderId,
                              HttpSession session,
                              RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            OrderResponse order = backendApi.returnOrder(orderId, user.token());
            redirectAttributes.addFlashAttribute("success",
                    "Book returned to " + order.storeName() + ". Refund of INR " + order.refundAmount() + " processed.");
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/orders", "Back to orders");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
        }
        return "redirect:/orders";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requireAdmin(session);
        if (user == null) return "redirect:/login";

        model.addAttribute("user", user);
        model.addAttribute("isAdmin", true);
        try {
            model.addAttribute("dashboard", backendApi.getAdminDashboard(user.token()));
            model.addAttribute("inventoryEvents", backendApi.getRecentInventoryEvents(user.token()));
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to browse");
            }
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "admin-dashboard";
    }

    @GetMapping("/admin/books")
    public String adminBooksPage(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requireAdmin(session);
        if (user == null) return "redirect:/login";
        model.addAttribute("user", user);
        model.addAttribute("isAdmin", true);
        try {
            model.addAttribute("stores", backendApi.listStores(user.token()));
        } catch (Exception e) {
            model.addAttribute("stores", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "admin-books";
    }

    @PostMapping("/admin/books")
    public String createBook(@RequestParam("title") String title,
                             @RequestParam("author") String author,
                             @RequestParam("isbn") String isbn,
                             @RequestParam("price") BigDecimal price,
                             @RequestParam("category") String category,
                             @RequestParam("description") String description,
                             @RequestParam("stock") int stock,
                             @RequestParam("storeId") Long storeId,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        AuthResponse user = requireAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            backendApi.createBook(new CreateBookRequest(title, author, isbn, price, category, description, stock,
                            "English", "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",
                            storeId),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Book added successfully.");
            return "redirect:/";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/admin/books";
        }
    }

    private AuthResponse currentUser(HttpSession session) {
        return (AuthResponse) session.getAttribute("user");
    }

    private AuthResponse requireUser(HttpSession session) {
        return currentUser(session);
    }

    private AuthResponse requireAdmin(HttpSession session) {
        AuthResponse user = currentUser(session);
        if (user == null || !user.isAdmin()) {
            return null;
        }
        return user;
    }
}
