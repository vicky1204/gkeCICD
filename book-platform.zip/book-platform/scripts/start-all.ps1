Write-Host "Building book-platform..."
mvn clean package -DskipTests
if ($LASTEXITCODE -ne 0) { exit 1 }

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Start-Process powershell -ArgumentList "-NoExit", "-Command", "mvn -pl user-service spring-boot:run"
Start-Sleep -Seconds 8
Start-Process powershell -ArgumentList "-NoExit", "-Command", "mvn -pl catalog-service spring-boot:run"
Start-Sleep -Seconds 5
Start-Process powershell -ArgumentList "-NoExit", "-Command", "mvn -pl notification-service spring-boot:run"
Start-Sleep -Seconds 5
Start-Process powershell -ArgumentList "-NoExit", "-Command", "mvn -pl order-service spring-boot:run"
Start-Sleep -Seconds 8
Start-Process powershell -ArgumentList "-NoExit", "-Command", "mvn -pl api-gateway spring-boot:run"
Start-Sleep -Seconds 5
Start-Process powershell -ArgumentList "-NoExit", "-Command", "mvn -pl web-ui spring-boot:run"

Write-Host "`nOpen http://localhost:8090"
Write-Host "API Gateway: http://localhost:8080"
