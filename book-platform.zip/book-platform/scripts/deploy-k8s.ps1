Write-Host "Deploying book-platform to Kubernetes..."
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/user-service.yaml
kubectl apply -f k8s/catalog-service.yaml
kubectl apply -f k8s/notification-service.yaml
kubectl apply -f k8s/order-service.yaml
kubectl apply -f k8s/api-gateway.yaml
kubectl apply -f k8s/web-ui.yaml
kubectl apply -f k8s/ingress.yaml
Write-Host "Done. Add 'book-platform.local' to hosts pointing at your ingress IP."
Write-Host "kubectl get pods -n book-platform"
