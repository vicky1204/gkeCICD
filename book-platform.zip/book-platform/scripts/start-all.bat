@echo off
echo Building book-platform...
call mvn clean package -DskipTests -q
if errorlevel 1 exit /b 1

echo Starting microservices in separate windows...
start "user-service" cmd /k "mvn -pl user-service spring-boot:run"
timeout /t 8 /nobreak >nul
start "catalog-service" cmd /k "mvn -pl catalog-service spring-boot:run"
timeout /t 5 /nobreak >nul
start "notification-service" cmd /k "mvn -pl notification-service spring-boot:run"
timeout /t 5 /nobreak >nul
start "order-service" cmd /k "mvn -pl order-service spring-boot:run"
timeout /t 8 /nobreak >nul
start "web-ui" cmd /k "mvn -pl web-ui spring-boot:run"

echo.
echo Open http://localhost:8090 in your browser
echo Press any key to exit this launcher (services keep running)...
pause >nul
