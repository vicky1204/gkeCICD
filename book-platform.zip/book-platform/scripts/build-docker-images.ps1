param(
    [string]$Version = "1.0.0"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$services = @(
    "user-service",
    "catalog-service",
    "notification-service",
    "order-service",
    "api-gateway",
    "web-ui"
)

foreach ($service in $services) {
    Write-Host "Building image book-platform/${service}:$Version"
    docker build -f docker/Dockerfile.service --build-arg MODULE=$service -t "book-platform/${service}:$Version" .
}

Write-Host "`nImages built. Deploy with:"
Write-Host "kubectl apply -f k8s/"
