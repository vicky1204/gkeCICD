# Book Platform — Microservices (Spring Boot)

A demo **book buying platform** with:
- **Microservices** architecture
- **H2 in-memory** databases (Phase 1 — swap to PostgreSQL later)
- **Kafka** optional (works without Kafka install via HTTP fallback)
- **WhatsApp** notifications (mock locally; Twilio-ready interface)
- **Thymeleaf** web UI

## Business model

1. Buyer **registers** and **logs in**
2. Searches books and **checks out** (pays full listed price)
3. Platform keeps **INR 5 percent of book cost** (service fee)
4. **Remaining amount** is refundable after return in good condition
5. **Terms & Conditions** must be accepted (no torn books, good return)
6. On **delivery**, WhatsApp notification is sent

## Architecture

| Service | Port | Responsibility |
|---------|------|----------------|
| **web-ui** | 8090 | Thymeleaf frontend |
| **api-gateway** | 8080 | Spring Cloud Gateway routes |
| **user-service** | 8081 | Registration, login, JWT |
| **catalog-service** | 8082 | Book catalog, search |
| **order-service** | 8083 | Checkout, payment split, orders |
| **notification-service** | 8084 | WhatsApp (mock/Kafka consumer) |

## Design patterns used

- **Repository** — JPA data access
- **Service layer** — business logic
- **DTO** — API contracts in `common` module
- **Strategy** — `PaymentSplitStrategy` (5% percent of book cost fee logic)
- **Factory / Strategy** — `WhatsAppNotifier` (mock vs real provider)
- **Event-driven** — Kafka `order-events` topic (optional)
- **API Gateway** — single entry for REST APIs

## Prerequisites

- **Java 17+**
- **Maven 3.9+**
- **Kafka** — optional (see below)

## Quick start (NO Kafka required)

Open **5 terminals** and run in this order:

```bash
cd book-platform
mvn -pl user-service -am package -DskipTests
mvn -pl catalog-service -am package -DskipTests
mvn -pl order-service -am package -DskipTests
mvn -pl notification-service -am package -DskipTests
mvn -pl web-ui -am package -DskipTests
```

Or build everything once:

```bash
mvn clean package -DskipTests
```

Start services:

```bash
# Terminal 1
mvn -pl user-service spring-boot:run

# Terminal 2
mvn -pl catalog-service spring-boot:run

# Terminal 3
mvn -pl notification-service spring-boot:run

# Terminal 4
mvn -pl order-service spring-boot:run

# Terminal 5 (optional gateway)
mvn -pl api-gateway spring-boot:run

# Terminal 6 — Web UI
mvn -pl web-ui spring-boot:run
```

**Open:** http://localhost:8090

### Windows script

```powershell
.\scripts\start-all.ps1
```

## Test flow

1. Register at http://localhost:8090/register (use phone like `919876543210`)
2. Search books on home page
3. Checkout → accept Terms → place order
4. Go to **My Orders** → click **Simulate Deliver**
5. Check **notification-service** console for WhatsApp mock message

## Kafka (Phase 2 — optional)

### Option A: Docker

```bash
docker compose up -d
```

Enable Kafka profile on order + notification services:

```bash
# order-service application.yml: app.kafka.enabled: true
# notification-service application.yml: app.kafka.enabled: true
# Remove kafka autoconfigure exclude and add spring.kafka.bootstrap-servers
```

Or use provided `application-kafka.yml` profile:

```bash
mvn -pl order-service spring-boot:run -Dspring-boot.run.profiles=kafka
mvn -pl notification-service spring-boot:run -Dspring-boot.run.profiles=kafka
```

### Without Kafka (default)

Order events are sent via **HTTP** directly to notification-service.

## WhatsApp (real integration — Phase 2)

Replace `MockWhatsAppNotifier` with Twilio WhatsApp API:

1. Create Twilio account + WhatsApp sandbox
2. Implement `TwilioWhatsAppNotifier implements WhatsAppNotifier`
3. Set `whatsapp.provider=twilio` in `notification-service`

## Phase 2 enhancements (your plan)

- [ ] PostgreSQL per service
- [ ] Kafka always on (remove HTTP fallback)
- [ ] Real payment gateway (Razorpay/Stripe)
- [ ] Real WhatsApp via Twilio
- [ ] Service discovery (Eureka)
- [ ] Docker/Kubernetes deployment

## API examples

```bash
# Register
curl -X POST http://localhost:8081/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Test User","email":"test@example.com","password":"secret1","phone":"919876543210"}'

# Search books
curl "http://localhost:8082/api/books?q=java"

# Checkout (userId=1)
curl -X POST http://localhost:8083/api/orders/checkout \
  -H "Content-Type: application/json" \
  -H "X-User-Id: 1" \
  -d '{"bookId":1,"quantity":1,"termsAccepted":true}'

# Mark delivered → triggers WhatsApp
curl -X POST http://localhost:8083/api/orders/1/deliver
```

## Project structure

```
book-platform/
├── common/                 # Shared DTOs, events, T&C
├── user-service/
├── catalog-service/
├── order-service/
├── notification-service/
├── api-gateway/
├── web-ui/
├── docker-compose.yml
└── scripts/
```

## License

Demo project for learning — customize as needed.
