package com.bookplatform.user.controller;

import com.bookplatform.common.dto.AuthResponse;
import com.bookplatform.common.dto.LoginRequest;
import com.bookplatform.common.dto.ResetPasswordRequest;
import com.bookplatform.common.dto.UserDto;
import com.bookplatform.common.dto.UserRegistrationRequest;
import com.bookplatform.common.openapi.OpenApiConstants;
import com.bookplatform.user.entity.User;
import com.bookplatform.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@Tag(name = "Users", description = "User registration, authentication, and profile")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @Operation(summary = "Register a new user")
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody UserRegistrationRequest request) {
        return ResponseEntity.ok(userService.register(request));
    }

    @Operation(summary = "Login and receive JWT token")
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(userService.login(request));
    }

    @Operation(summary = "Reset password (no email verification)")
    @PostMapping("/reset-password")
    public ResponseEntity<Void> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        userService.resetPassword(request);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Get user profile by ID")
    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUser(@PathVariable("id") Long id, Authentication authentication) {
        Long authenticatedUserId = (Long) authentication.getPrincipal();
        if (!authenticatedUserId.equals(id)) {
            throw new IllegalArgumentException("Access denied");
        }
        User user = userService.getById(id);
        return ResponseEntity.ok(new UserDto(user.getId(), user.getFullName(), user.getEmail(), user.getPhone()));
    }
}
