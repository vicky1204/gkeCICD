package com.bookplatform.user.config;

import com.bookplatform.common.dto.UserRole;
import com.bookplatform.user.entity.User;
import com.bookplatform.user.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AdminDataInitializer {

    @Bean
    CommandLineRunner seedAdmin(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            String adminEmail = "admin@bookplatform.local";
            if (userRepository.existsByEmail(adminEmail)) {
                return;
            }
            User admin = new User();
            admin.setFullName("Platform Admin");
            admin.setEmail(adminEmail);
            admin.setPasswordHash(passwordEncoder.encode("admin123"));
            admin.setPhone("919999999999");
            admin.setRole(UserRole.ADMIN);
            userRepository.save(admin);
        };
    }
}
